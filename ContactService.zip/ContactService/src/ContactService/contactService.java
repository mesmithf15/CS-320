package ContactService;

import java.util.Vector;


import java.util.Random;

public class contactService {
	
	//generate unique ID
	public String generateUniqueId() {
		Random rand = new Random();
		int randIdNum = rand.nextInt(1000000000);
		String uniqueId = Integer.toString(randIdNum);
		
		Vector<String> idList = new Vector<String>();
				for(Contact c: contactList) {
			idList.add(c.getContactId());
			
		}
		
		while(idList.contains(uniqueId) || uniqueId.length() > 10) {
					
			randIdNum = rand.nextInt(1000000000);
			uniqueId = Integer.toString(randIdNum);
		}
				
		idList = null;
		return uniqueId;
	}
		//Creates a vector for contact list
	public static Vector<Contact> contactList = new Vector<Contact>();
	
	public String contactId;
	public String firstName;
	public String lastName;
	public String phoneNum;
	public String address;
	
	//Adds new contact to list
	public void addContact(String contactId, String firstName, String lastName, String phoneNum, String address) {
		
		//takes new contact and gets information to be added to list
		Contact newContact = new Contact(contactId, firstName, lastName, phoneNum, address);
		
		contactList.add(newContact);
		
	}
	
	//Deletes contact based on matching contact ID
	public void deleteContact(String contactId) {
		
		if(contactId.length() > 10 || contactId == null) {
			throw new IllegalArgumentException("Invaid ID");
		}
		else if(contactList.contains(contactId)) {
			contactList.remove(contactId);

		}
			
	}
	
	//Updates contact information, first name, last name, phone number, and address
	public void updateContact(String contactId, String update, int option ) {
		
		if(contactId.length() > 10 || contactId == null || update == null || option < 0) {
			throw new IllegalArgumentException("Invalid ID");
		}
		
		Contact updateContact = contactList.get(option);
		
		switch (option) {
		case 1:{
			updateContact.setFirstName(update);
			break;
		}
		case 2:{
			updateContact.setLastName(update);
		}
		case 3:{
			updateContact.setPhoneNum(update);
		}
		case 4:{
			updateContact.setAddress(update);
		}
	}
		

	}
}
