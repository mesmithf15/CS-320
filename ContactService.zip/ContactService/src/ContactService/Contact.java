package ContactService;


public class Contact {
	
	private String contactId;
	private String firstName;
	private String lastName;
	private String phoneNum;
	private String address;
	private String fullName;
	
	//Default constructor
	public Contact(String contactId, String firstName, String lastName, String phoneNum, String Address) {
		
		//Checks to see if required data fits requirements
		if(contactId.length() > 10 || contactId == null) {
			throw new IllegalArgumentException("Invalid ID");
		}
		if(firstName.length() > 10 || firstName == null) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		if(lastName.length() > 10 || lastName == null) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		if(phoneNum.length() > 10 || phoneNum == null) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		if(address.length() > 10 || address == null) {
			throw new IllegalArgumentException("Invalid Address");
		}
		
		//Code that sets information entered if passed
		this.contactId = contactId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNum = phoneNum;
		this.address = address;
	}

	//Set and get for contact ID
	public String getContactId() {
		return contactId;
	}

	public void setContactId(String contactId) {
		if(contactId.length() > 10 || contactId == null) {
			throw new IllegalArgumentException("Invalid Contact ID");
		}
		else {
			this.contactId = contactId;
		}
	}

	
	//set and get for last name
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		if(lastName.length() > 10 || lastName == null) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		else {
			this.lastName = lastName;
		}
	}

	//set and get for first name
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		if(firstName.length() > 10 || firstName == null) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		else {
			this.firstName = firstName;
		}
	}

	//set and get for home address
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		if(address.length() > 30 || address == null) {
			throw new IllegalArgumentException("Invalid Address");
		}
		else {
			this.address = address;
		}
	}

	//set and get for phone number
	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		if(phoneNum.length() > 10 || phoneNum == null) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		else {
			this.phoneNum = phoneNum;
		}
	}
	
	//get for full name
	public String getFullName() {
		return this.firstName + " " + this.lastName;
	}
	
	
	
	

}
