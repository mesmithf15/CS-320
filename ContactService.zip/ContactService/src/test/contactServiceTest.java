package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import ContactService.Contact;
import ContactService.contactService;

class contactServiceTest {

	@Test
	void testAddContact() {
		
		contactService contact = new contactService();
		
		String contactId = contact.generateUniqueId();
		String firstName = "Steve";
		String lastName = "Rogers";
		String phoneNum = "1112223333";
		String address = "123 Avengers Drive";
		
		
		contact.addContact( contactId, firstName, lastName, phoneNum, address);
		
	}
	
	void testDeleteContact() {
		
		
		contactService contact = new contactService();
		
		String contactId = contact.generateUniqueId();
		String firstName = "Steve";
		String lastName = "Rogers";
		String phoneNum = "1112223333";
		String address = "123 Avengers Drive";
		
		
		contact.addContact( contactId, firstName, lastName, phoneNum, address);
		
		contact.deleteContact(contactId);
	}

}
