package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import ContactService.Contact;

class ContactTest {

	//test null arguments
	@Test
	void testContactNullArguments() { 
		Assertions.assertThrows(IllegalArgumentException.class,()-> {
		new Contact(null, null, null, null, null);
	});

	}

	//tests the getters for the contact java
	@Test
	void testContactAndGetters() {
		Contact contact = new Contact("142452", "Steve", "Rogers", "2123657866", "123 Avengers Drive");
		assertTrue(contact.getFullName().equals("Steve Rogers"));
		assertTrue(contact.getPhoneNum().equals("2123657866"));
		assertTrue(contact.getAddress().equals("123 Avengers Drive"));
		assertTrue(contact.getContactId().equals("142452"));
	}
	
	//test the set for the first and last name
	@Test
	void testSetFirstAndLastName() {
		Contact contact = new Contact("142452", "Steve", "Rogers", "2123657866", "123 Avengers Drive");
		contact.setFirstName("Steve");
		contact.setLastName("Rogers");
		assertTrue(contact.getFullName().equals("Steve Rogers"));
	}
	
	//test the set for phone number and address
	@Test
	void testSetPhoneNumberAndAddress() {
		Contact contact = new Contact("142452", "Steve", "Rogers", "2123657866", "123 Avengers Drive");
		contact.setPhoneNum("2123657866");
		contact.setAddress("123 Avengers Drive");
	}
	
	//tests null input for arguments
	@Test
	void testNullSetInputs() {
		Contact contact = new Contact("142452", "Steve", "Rogers", "2123657866", "123 Avengers Drive");
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setFirstName(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setLastName(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setPhoneNum(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setAddress(null);
		});
	}
	
	//test all getters for the contact java
	@Test
	void testAllGetters() {
		Contact contact = new Contact("142452", "Steve", "Rogers", "2123657866", "123 Avengers Drive");
		assertTrue(contact.getFullName().equals("Steve Rogers"));
		assertTrue(contact.getContactId().equals("142452"));
		assertTrue(contact.getPhoneNum().equals("2123657866"));
		assertTrue(contact.getAddress().equals("123 Avengers Drive"));
	}
	
}
